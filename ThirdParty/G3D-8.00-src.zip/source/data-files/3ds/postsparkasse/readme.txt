

Get more informations about the renderchallenge from: 

http://hdri.cgtechniques.com/~postspar/



The file is part of a set from different 3d files formats 
and can be used without limitations by naming the author 
of this file and the link above.


have fun!



(c)2002 all rights reserved christian@cgtechniques.com <christian Bauer> 
