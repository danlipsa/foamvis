package G3D;

public interface BinaryDeserializable {
    public void deserialize(BinaryInput input);
}
